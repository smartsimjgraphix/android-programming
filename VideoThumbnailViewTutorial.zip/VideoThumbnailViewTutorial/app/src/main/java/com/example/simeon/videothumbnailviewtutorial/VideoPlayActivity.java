package com.example.simeon.videothumbnailviewtutorial;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageButton;

import com.bumptech.glide.Glide;

public class VideoPlayActivity extends AppCompatActivity implements SurfaceHolder.Callback, MediaPlayer.OnCompletionListener {

    private MediaPlayer mMediaPlayer;
    private Uri mVideoUri;
    private ImageButton mPlayPauseButton;
    private SurfaceView mSurfaceView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_play);

        mPlayPauseButton = (ImageButton)findViewById(R.id.videoPlayPauseButton);
        mSurfaceView = (SurfaceView)findViewById(R.id.videoSurfaceView);

        Intent callingActivityIntent = getIntent();
        if(callingActivityIntent != null){
            mVideoUri = callingActivityIntent.getData();
        }

    }

    public void PlayPauseClick(View view) {
        if(mMediaPlayer.isPlaying()){
            mediaPause();
        }else {
            mediaPlay();
        }

    }

    private void mediaPlay(){
        mMediaPlayer.start();
        mPlayPauseButton.setImageResource(R.drawable.ic_pause_black_24dp);

    }

    private void mediaPause(){
        mMediaPlayer.start();
        mPlayPauseButton.setImageResource(R.drawable.ic_play_arrow_black_24dp);

    }

    @Override
    protected void onStop() {
        if(mMediaPlayer != null){
            mMediaPlayer.stop();
            mMediaPlayer.release();
            mMediaPlayer = null;

        }
        super.onStop();
    }

    @Override
    protected void onPause() {
        super.onPause();
        mediaPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(mMediaPlayer != null){
            mediaPlay();
        }else{
            SurfaceHolder surfaceHolder = mSurfaceView.getHolder();
            surfaceHolder.addCallback(this);
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        mMediaPlayer = MediaPlayer.create(this, mVideoUri, holder);
        mMediaPlayer.setOnCompletionListener(this);
        mediaPlay();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {

    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        mPlayPauseButton.setImageResource(R.drawable.ic_play_arrow_black_24dp);
    }
}
