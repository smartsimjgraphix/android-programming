package com.example.simeon.videothumbnailviewtutorial;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class MediaStoreAdapter extends RecyclerView.Adapter<MediaStoreAdapter.ViewHolder> {

    private Cursor mMediaStoreCursor;
    private final Activity mActivity;

    private OnClickThumbnailListener mOnClickThumbnailListener;

    public interface OnClickThumbnailListener{
        void OnClickImage(Uri imageUri);
        void OnClickVideo(Uri videoUri);
    }

    public MediaStoreAdapter(Activity activity) {
        this.mActivity = activity;
        this.mOnClickThumbnailListener = (OnClickThumbnailListener)activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.media_image_view, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        /*Bitmap bitmap = getBitmapThumbMediaStore(i);
        if(bitmap != null){
            viewHolder.getmImageView().setImageBitmap(bitmap);
        }*/
        Glide.with(mActivity)
                .load(getUriFromMediaStore(i))
                .centerCrop()
                .override(96,96)
                .into(viewHolder.getmImageView());
    }

    @Override
    public int getItemCount() {
        return (mMediaStoreCursor == null)? 0: mMediaStoreCursor.getCount();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ImageView mImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = (ImageView)itemView.findViewById(R.id.mediaStoreImageView);
            mImageView.setOnClickListener(this);
        }

        public ImageView getmImageView(){
            return mImageView;
        }

        @Override
        public void onClick(View v) {
            getOnClickUri(getAdapterPosition());
        }
    }

    private Cursor swapCursor(Cursor cursor){
        if(mMediaStoreCursor == cursor){
            return null;
        }
        Cursor oldCursor = mMediaStoreCursor;
        this.mMediaStoreCursor = cursor;
        if(cursor!= null){
            this.notifyDataSetChanged();

        }

        return oldCursor;
    }

    public void changeCursor(Cursor cursor){
        Cursor oldCursor = swapCursor(cursor);
        if(oldCursor != null){
            oldCursor.close();
        }
    }

    private Bitmap getBitmapThumbMediaStore(int position){
        int idIndex = mMediaStoreCursor.getColumnIndex(MediaStore.Files.FileColumns._ID);
        int mediaTypeIndex = mMediaStoreCursor.getColumnIndex(MediaStore.Files.FileColumns.MEDIA_TYPE);
        mMediaStoreCursor.moveToPosition(position);
        switch (mMediaStoreCursor.getInt(mediaTypeIndex)){

            case MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE:
                return MediaStore.Images.Thumbnails.getThumbnail(
                  mActivity.getContentResolver(),
                  mMediaStoreCursor.getLong(idIndex),
                  MediaStore.Images.Thumbnails.MICRO_KIND,
                  null
                );

            case MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO:
                return MediaStore.Video.Thumbnails.getThumbnail(
                        mActivity.getContentResolver(),
                        mMediaStoreCursor.getLong(idIndex),
                        MediaStore.Video.Thumbnails.MICRO_KIND,
                        null
                );

            default:
                return null;
        }
    }

    private Uri getUriFromMediaStore(int position){
        int dataIndex = mMediaStoreCursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);
        mMediaStoreCursor.moveToPosition(position);

        String dataString = mMediaStoreCursor.getString(dataIndex);
        Uri mediaUrl = Uri.parse("file://" + dataString);
        return mediaUrl;
    }

    public void getOnClickUri(int position){
        int mediaTypeIndex = mMediaStoreCursor.getColumnIndex(MediaStore.Files.FileColumns.MEDIA_TYPE);
        int dataIndex = mMediaStoreCursor.getColumnIndex(MediaStore.Files.FileColumns.DATA);

        String dataString = mMediaStoreCursor.getString(dataIndex);
        Uri mediaUrl = Uri.parse("file://" + dataString);

        mMediaStoreCursor.moveToPosition(position);
        switch (mMediaStoreCursor.getInt(mediaTypeIndex)){
            case MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE:

                mOnClickThumbnailListener.OnClickImage(mediaUrl);
                break;
            case MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO:
                mOnClickThumbnailListener.OnClickVideo(mediaUrl);
                break;
                default:
        }
    }
}
