package com.smartsimjgrapihix.simeon.ngtapp;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class ActivityVehicle extends AppCompatActivity {

    private DatePickerDialog.OnDateSetListener mDateListener;
    static final int REQUEST_IMAGE_CAPTURE = 1;
    EditText etRegistrationNumber, etMilage, etEngineNumber, etVINDetail;
    AutoCompleteTextView autoVehicleMake, autoVehicleColor;
    Button btnVehicleDetailsNext;
    TextView tvPickDateAndTime;
    Spinner spinnerVehicleType, spinnerYearMake;
    ImageView imageViewInitiateCamera, imageViewOne, imageViewTwo, imageViewThree;

    String carMakeYear[] = {"1980","2017","2018", "2019"};
    String carType[] = {"Small","Medium","Heavy"};
    String carColor[] = {"White","Black","Yellow"};


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQUEST_IMAGE_CAPTURE & resultCode == RESULT_OK){
            Bundle extras = data.getExtras();
            Bitmap photoTaken = (Bitmap)extras.get("data");
            imageViewOne.setImageBitmap(photoTaken);
            imageViewTwo.setImageBitmap(photoTaken);
            imageViewThree.setImageBitmap(photoTaken);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle);
        if(!hasCamera()){
            imageViewInitiateCamera.setEnabled(false);
        }

        tvPickDateAndTime = (TextView)findViewById(R.id.tv_vd_pickDateAndTime);


        etRegistrationNumber = (EditText)findViewById(R.id.et_vd_registrationNumber);
        etMilage = (EditText)findViewById(R.id.et_vd_mileage);
        etEngineNumber = (EditText)findViewById(R.id.tv_vd_engine_number);
        etVINDetail = (EditText)findViewById(R.id.et_vd_vin);


        //autocompletextViews
        autoVehicleMake = (AutoCompleteTextView)findViewById(R.id.et_vd_vehicle_make);
        autoVehicleColor = (AutoCompleteTextView)findViewById(R.id.et_vd_vehicle_color);

        //Spinner
        spinnerVehicleType= (Spinner)findViewById(R.id.spinner_vd_vehicle_type);
        spinnerYearMake =(Spinner)findViewById(R.id.spinner_vd_year);

        ListAdapter adapterCarType = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, carType);
        spinnerVehicleType.setAdapter((SpinnerAdapter) adapterCarType);

        ListAdapter adapterYearMAke = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, carMakeYear);
        spinnerYearMake.setAdapter((SpinnerAdapter) adapterYearMAke);

        imageViewInitiateCamera = (ImageView)findViewById(R.id.imageView_vd_initiateCamera);
        imageViewOne = (ImageView)findViewById(R.id.imageView_vd_img_one);
        imageViewTwo = (ImageView)findViewById(R.id.imageView_vd_img_two);
        imageViewThree = (ImageView)findViewById(R.id.imageView_vd_img_three);


        imageViewInitiateCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intentCamera, REQUEST_IMAGE_CAPTURE);
            }
        });

        //requesting for the photo taken: Retrieving Photo



        tvPickDateAndTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar cal = Calendar.getInstance();
                int year = cal.get(Calendar.YEAR);
                int month = cal.get(Calendar.MONTH);
                final int day = cal.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(ActivityVehicle.this,
                        android.R.style.Theme_DeviceDefault_Dialog_MinWidth, mDateListener, year, month, day);
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();

                mDateListener = new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        month = month+1;
                        String date = month + "/"+ day + "/"+ year;
                        Toast.makeText(ActivityVehicle.this, "You Picked " + date, Toast.LENGTH_SHORT).show();
                    }
                };
            }
        });


        btnVehicleDetailsNext = (Button)findViewById(R.id.btn_vd_next);
        btnVehicleDetailsNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityVehicle.this, ActivityTracker.class));
            }
        });


    }

    private boolean hasCamera() {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);
    }
}
