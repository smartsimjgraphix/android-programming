package com.smartsimjgrapihix.simeon.ngtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityTracker extends AppCompatActivity {

    Button btnTackerNext;
    Spinner spinnerSelectTrackerType;
    EditText etTrackerPhoneNumber, etTrackerSIMSerialNumber;
    CheckBox checkBoxSimHybrid;
    TextView tvDeviceType, tvDeviceID, tvDeviceIMEI, tvAddTrackerAuthUser, tvLoginTracker, tvTrackerAccessories;
    View inflatedAuthUserDetails, inflatedTrackerLogintDetails, inflatedAccessoriesDetails;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracker);
        inflatedAuthUserDetails = getLayoutInflater().inflate( R.layout.dialog_tracker_add_auth_user, null);
        inflatedTrackerLogintDetails = getLayoutInflater().inflate( R.layout.dialog_tracker_log_tracker_in, null);
        inflatedAccessoriesDetails = getLayoutInflater().inflate( R.layout.dialog_tracker_add_accessories, null);


        btnTackerNext = (Button)findViewById(R.id.btn_tracker_next);;
        //spinner
        spinnerSelectTrackerType = (Spinner)findViewById(R.id.spinner_tracker_select_device);

        //editTexts
        etTrackerPhoneNumber = (EditText)findViewById(R.id.et_tracker_phoneNumber);
        etTrackerSIMSerialNumber = (EditText)findViewById(R.id.et_tracker_sim_serial);

        //CheckBox
        checkBoxSimHybrid = (CheckBox)findViewById(R.id.checkBox_tracker_m2m_hybrid);

        //TextViews
        tvDeviceType = (TextView)findViewById(R.id.tv_tracker_device_type);
        tvDeviceID = (TextView)findViewById(R.id.tv_tracker_device_id);
        tvDeviceIMEI = (TextView)findViewById(R.id.tv_tracker_imei_number);
        tvAddTrackerAuthUser = (TextView)findViewById(R.id.tv_tracker_add_auth_users);
        tvLoginTracker = (TextView)findViewById(R.id.tv_tracker_login_tracker);
        tvTrackerAccessories = (TextView)findViewById(R.id.tv_tracker_accessories);

        tvAddTrackerAuthUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ActivityTracker.this)
                        .setView(inflatedAuthUserDetails)
                        .setTitle("ADD AUTHOURISED USER DETAILS")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                builder.create();
                builder.show();
            }
        });

        tvLoginTracker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ActivityTracker.this)
                        .setView(inflatedTrackerLogintDetails)
                        .setTitle("LOG TRACKER IN")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                builder.create();
                builder.show();
            }
        });

        tvTrackerAccessories.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ActivityTracker.this)
                        .setView(inflatedAccessoriesDetails)
                        .setTitle("TRACKER ACCESSORIES")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                builder.create();
                builder.show();
            }
        });

        //button action
        btnTackerNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityTracker.this, ActivitySensor.class));
            }
        });



    }
}
