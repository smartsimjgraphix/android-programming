package com.smartsimjgrapihix.simeon.ngtapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class ActivityCreateClient extends AppCompatActivity {

    Button btnCreateClientNext;
    TextView tvEmailDetails, tvContactDetails;
    EditText etClientName, etClientDescription, etLoginAccountName, etClientPassword;
    Spinner spinnerContractType;

    String[] contractTypeData = {"Once Off", "6 Months"};
    View inflatedEmailDetails, inflatedContactDetails;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_client);
        inflatedEmailDetails = getLayoutInflater().inflate( R.layout.dialog_cnc_email_details, null);
        inflatedContactDetails = getLayoutInflater().inflate( R.layout.dialog_cnc_contact_details, null);

        spinnerContractType = (Spinner)findViewById(R.id.spinner_cnc_contract_type);
        ListAdapter contractAdapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, contractTypeData);
        spinnerContractType.setAdapter((SpinnerAdapter) contractAdapter);

        //Buttons
        btnCreateClientNext = (Button)findViewById(R.id.btn_cnc_next);


        //TextViews
        tvEmailDetails = (TextView)findViewById(R.id.tv_cnc_email_details);
        tvContactDetails = (TextView)findViewById(R.id.tv_cnc_contact_details);

        //Edittexts
        etClientName = (EditText)findViewById(R.id.et_cnc_client_name);
        etClientDescription = (EditText)findViewById(R.id.et_cnc_client_description);
        etLoginAccountName =(EditText)findViewById(R.id.et_cnc_accName);
        etClientPassword = (EditText)findViewById(R.id.et_cnc_password);


        tvEmailDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ActivityCreateClient.this)
                        .setView(inflatedEmailDetails)
                        .setTitle("EMAIL DETAILS")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                builder.create();
                builder.show();
            }
        });

        tvContactDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ActivityCreateClient.this)
                        .setView(inflatedContactDetails)
                        .setTitle("CONTACTS DETAILS")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                builder.create();
                builder.show();
            }
        });

        btnCreateClientNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ActivityCreateClient.this, ActivityVehicle.class));
            }
        });

    }
}
