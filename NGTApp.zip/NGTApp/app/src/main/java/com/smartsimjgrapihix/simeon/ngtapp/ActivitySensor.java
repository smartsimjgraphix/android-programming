package com.smartsimjgrapihix.simeon.ngtapp;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class ActivitySensor extends AppCompatActivity {

    //inside normal activity
    Button btnSave;
    Spinner spinnerSelectDevice, spinnerSensorLength, spinnerTankCapacity;
    EditText etSensorDetails, etSensorPassword;
    TextView tvFuelSensororeDetails, tvFuelSensorType, tvSensorId;
    View inflatedTankMoreDetails;

    //alert Dialog inflator


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor);

        inflatedTankMoreDetails = getLayoutInflater().inflate( R.layout.dialog__sensor_tank_more_details, null);

        //Buttons
        btnSave = (Button)findViewById(R.id.btn_sensor_details_save);

        //Spinners
        spinnerSelectDevice = (Spinner)findViewById(R.id.spinner_sensor_select_device);
        spinnerSensorLength = (Spinner)findViewById(R.id.spinner_sensor_length);
        spinnerTankCapacity = (Spinner)findViewById(R.id.spinner_sensor_tank_capacity);

        //EditTexts
        etSensorDetails = (EditText)findViewById(R.id.et_sensor_details);
        etSensorPassword = (EditText)findViewById(R.id.et_sensor_password);

        //Textviews
        tvFuelSensororeDetails = (TextView)findViewById(R.id.tv_sensor_tank_moredetails);
        tvFuelSensorType = (TextView)findViewById(R.id.tv_sensor_f_sensor_type);
        tvSensorId = (TextView)findViewById(R.id.tv_sensor_serial_number);

        tvFuelSensororeDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ActivitySensor.this)
                        .setView(inflatedTankMoreDetails)
                        .setTitle("FUEL TANK MORE DETAILS")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                return;
                            }
                        });
                builder.create();
                builder.show();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });





    }
}
